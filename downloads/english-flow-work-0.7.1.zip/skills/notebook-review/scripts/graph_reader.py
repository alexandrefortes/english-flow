from contextlib import closing
import re
import sqlite3


TOPICS = {
    "gramatica": "Gramática",
    "conversacao": "Conversação",
    "vocabulario": "Vocabulário",
    "phrasal-verbs": "Phrasal verbs",
    "linguagem-informal": "Linguagem informal e gírias",
    "dia-a-dia": "Dia a dia no trabalho",
    "pronuncia": "Pronúncia",
}
SITUATIONS = {
    "pedir-atualizacao": "Pedir uma atualização",
    "negociar-prazo": "Negociar um prazo",
    "dar-feedback": "Dar feedback",
    "confirmar-proximos-passos": "Confirmar próximos passos",
    "se-apresentar": "Apresentar-se a novos colegas",
    "pedir-ajuda": "Pedir ajuda",
    "esclarecer": "Pedir esclarecimento",
    "comunicar-risco": "Comunicar risco",
}


def open_read_only(path, indice=None):
    db = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
    if indice and indice.is_file():
        try:
            db.execute("ATTACH DATABASE ? AS wiki", (indice.resolve().as_uri() + "?mode=ro",))
            db.executescript("""
                CREATE TEMP VIEW nos AS
                SELECT * FROM main.nos WHERE tipo IN ('tema','situacao')
                UNION ALL
                SELECT i.id, CASE i.tipo WHEN 'topico' THEN 'conversa' ELSE i.tipo END,
                       CASE WHEN i.tipo IN ('topico','mensagem') AND instr(n.titulo,' · ') > 0
                            THEN substr(n.titulo,1,instr(n.titulo,' · ')+2) || i.titulo
                            ELSE i.titulo END,i.fonte,n.origem,i.url,i.pagina,i.texto,i.qualidade,i.ordem
                FROM wiki.itens i LEFT JOIN main.nos n ON n.id=i.id;
                CREATE TEMP VIEW ligacoes AS
                SELECT l.* FROM main.ligacoes l JOIN wiki.itens i ON i.id=l.origem
                WHERE l.relacao='candidato' AND instr(' '||i.rotulos||' ', ' '||l.destino||' ')
                UNION ALL SELECT id,pai,'pertence',NULL FROM wiki.itens WHERE pai IS NOT NULL
                UNION ALL SELECT b.anexo,b.mensagem,'mencionado-em',NULL FROM wiki.backlinks b
                          JOIN wiki.itens m ON m.id=b.mensagem
                UNION ALL SELECT e.id,j.value,'curado',min(e.trecho) FROM wiki.evidencias e
                          JOIN wiki.inventario i ON i.id=e.id AND i.estado='conferido',
                          json_each('["' || replace(e.usos,' ','","') || '"]') j GROUP BY e.id,j.value;
            """)
        except BaseException:
            db.close()
            raise
    return closing(db)


def pagina_local(db, wiki, identificador, url):
    if db.execute("SELECT 1 FROM pragma_database_list WHERE name='wiki'").fetchone():
        linha = db.execute("SELECT pagina,tipo FROM wiki.itens WHERE id=?", (identificador,)).fetchone()
        if linha:
            return linha[0] + ("#" + identificador if linha[1] == "mensagem" else "")
    ancora = ""
    if re.fullmatch(r"doist-[a-z0-9-]+", identificador):
        pagina = f"local/doist/{identificador}.md"
    elif identificador in TOPICS:
        pagina = f"{identificador}.md"
    elif identificador in SITUATIONS:
        pagina, ancora = "situacoes.md", "#" + identificador
    else:
        canal = re.search(r"/(?:channel|stream)/(\d+)", url or "")
        if not canal:
            return None
        topico = identificador
        if re.fullmatch(r"zulip-msg-\d+", identificador):
            linha = db.execute("SELECT destino FROM ligacoes WHERE origem=? AND relacao='pertence'",
                               (identificador,)).fetchone()
            if not linha:
                return None
            topico, ancora = linha[0], "#" + identificador
        if not re.fullmatch(r"zulip-topico-[0-9a-f]{24}", topico):
            return None
        pagina = f"local/zulip/canal-{canal[1]}/{topico}.md"
    return pagina + ancora if (wiki / pagina).is_file() else None


def find_examples(db, wiki, *, tema=None, situacao=None, fonte=None, texto=None, curados=False, limite=10, pular=0):
    filtros = ["n.tipo IN ('mensagem', 'captura')"]
    valores = []
    destinos = [destino for destino in (tema, situacao) if destino]
    for destino in destinos:
        origem = " AND l.relacao='curado'" if curados else ""
        filtros.append(f"EXISTS (SELECT 1 FROM ligacoes l WHERE l.origem=n.id AND l.destino=?{origem})")
        valores.append(destino)
    if curados and not (tema or situacao):
        filtros.append("EXISTS (SELECT 1 FROM ligacoes l WHERE l.origem=n.id AND l.relacao='curado')")
    if fonte:
        filtros.append("n.fonte = ?")
        valores.append(fonte)
    if texto:
        filtros.append("(instr(lower(n.texto), lower(?)) > 0 OR instr(lower(n.titulo), lower(?)) > 0)")
        valores.extend((texto, texto))
    where = " AND ".join(filtros)
    cursor = db.execute(f"""
        SELECT n.id, n.fonte, n.titulo, n.url, n.estado, substr(n.texto,1,320) AS previa
        FROM nos n WHERE {where}
        ORDER BY EXISTS (SELECT 1 FROM ligacoes l WHERE l.origem=n.id AND l.relacao='curado') DESC,
                 n.ordem DESC, n.id
        LIMIT ? OFFSET ?
    """, (*valores, limite, pular))
    resultados = []
    for linha in cursor:
        vinculos = db.execute("""
            SELECT destino, relacao, trecho FROM ligacoes
            WHERE origem=? AND relacao IN ('curado','candidato')
            ORDER BY destino, relacao DESC
        """, (linha["id"],))
        classificacao = [dict(vinculo) for vinculo in vinculos
                         if not destinos or vinculo["destino"] in destinos]
        resultados.append({**dict(linha), "classificacao": classificacao,
                           "pagina_local": pagina_local(db, wiki, linha["id"], linha["url"])})
    return resultados


def read_node(db, wiki, identificador):
    no = db.execute("SELECT * FROM nos WHERE id=?", (identificador,)).fetchone()
    if no is None:
        raise ValueError(f'Graph node not found: {identificador}')
    saidas = db.execute("""
        SELECT l.destino AS id, l.relacao, l.trecho, n.titulo, n.caminho
        FROM ligacoes l JOIN nos n ON n.id=l.destino
        WHERE l.origem=? ORDER BY l.relacao, l.destino
    """, (identificador,))
    entradas = db.execute("""
        SELECT relacao, count(*) AS quantidade FROM ligacoes WHERE destino=? GROUP BY relacao
    """, (identificador,))
    return {"no": dict(no), "pagina_local": pagina_local(db, wiki, identificador, no["url"]),
                   "ligacoes": [dict(linha) for linha in saidas],
                   "ligacoes_recebidas": {linha["relacao"]: linha["quantidade"] for linha in entradas}}
